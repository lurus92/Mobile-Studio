# Mobile Studio
Mobile Studio is a simple, cross-platform NativeScript IDE able to develop applications for iOS and Android.

## Libraries and Technology Used:
• jQuery Mobile
• jQueryUI (for resizing, dragging, etc.)
• Electron (to convert a javascript app to a native desktop one)
